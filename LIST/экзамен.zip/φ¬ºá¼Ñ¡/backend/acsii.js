const {Schema, model} = require('mongoose');

const AcsiiSchema = new Schema({
    name: {type: String, required: true},
    costold: {type: Number, required: true},
    costnew: {type: String, required: true},
    type: {type: String, required: true}
})
module.exports = model('Acsii', AcsiiSchema, 'acsii');
