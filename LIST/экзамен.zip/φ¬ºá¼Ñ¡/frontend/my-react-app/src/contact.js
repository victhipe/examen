function Contact(){

    return(
        <div>
125009, г. Москва, ул. Тверская, д. 15, офис 101».

+7 (495) 123‑45‑67 (Москва, пн–пт 9:00–18:00)

sportinfo@mail.ru

        </div>
    )
}
export default Contact;