import { useState } from "react";

function Login(){
    const [login, Setlogin] = useState('');
     const [password, Setpassword] = useState('');
      const [warn, Setwarn]= useState('');
      const [cool, Setcool]= useState('');
     function PostLogin(){
        const data = {
            login: login,
            password: password,
        }
        fetch('http://localhost:9001/api/login', {
            method: "POST",
            headers: {'content-type': 'application/json'},
            body: JSON.stringify(data)
        })
        .then(res=>{if(!res.ok){return res.json().then(err=>Setwarn(err.message))};return res.json()})
        .then(data=>{Setcool(data.message); localStorage.setItem('token', JSON.stringify(data.token));localStorage.setItem('login', JSON.stringify(login))})
        .catch(err=>console.log(err));
        window.location.reload();
     }
    return (
        <div>
      <input onChange={(e)=>{Setlogin(e.target.value)}} placeholder="Логин"></input>
      <input onChange={(e)=>{Setpassword(e.target.value)}} placeholder="Пароль"></input>
        <div>{warn}</div>
        <div>{cool}</div>
        <button onClick={()=>(PostLogin())}>Логин</button>
        </div>

    )
}
export default Login;