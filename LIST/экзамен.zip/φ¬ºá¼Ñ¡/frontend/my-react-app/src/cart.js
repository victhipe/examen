import { useState } from "react";

function Cart(){
    const [cart, Setcart] = useState(JSON.parse(localStorage.getItem('cart') || '[]'));
    function Cart2del(item){
        const newcart = cart.filter((x)=>(x._id !== item._id));
        Setcart(newcart);
        localStorage.setItem('newcart', JSON.stringify(newcart))
    }
    return(
        <>
        {cart.length === 0 ? (<div>Корзинка пустая</div>) : (<div>  {cart.map((item)=>(<div key={item._id}>
    <div>{item.cost} Р</div>
     <div>{item.name}</div>
     <div>{item.type}</div>
     <button onClick={()=>(Cart2del(item))}> Удалить</button>
   </div>))}</div>)} 
        </>
    )
}
export default Cart;