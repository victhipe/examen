import { useState } from "react";

function Register(){
    const [login, Setlogin] = useState('');
     const [password, Setpassword] = useState('');
      const [email, Setemail] = useState('');
      const [adress, Setadress] = useState('');
      const [warn, Setwarn]= useState('');
      const [cool, Setcool]= useState('');
     function PostReg(){
        const data = {
            login: login,
            password: password,
            email: email,
            adress: adress
        }
        fetch('http://localhost:9001/api/register', {
            method: "POST",
            headers: {'content-type': 'application/json'},
            body: JSON.stringify(data)
        })
        .then(res=>{if(!res.ok){return res.json().then(err=>Setwarn(err.message))};return res.json()})
        .then(data=>{Setcool(data.message)})
        .catch(err=>console.log(err));
        window.location.reload();
     }
    return (
        <div>
      <input onChange={(e)=>{Setlogin(e.target.value)}} placeholder="Логин"></input>
      <input onChange={(e)=>{Setpassword(e.target.value)}} placeholder="Пароль"></input>
        <input onChange={(e)=>{Setemail(e.target.value)}} placeholder="Почта"></input>
        <input onChange={(e)=>{Setadress(e.target.value)}} placeholder="Адрес домашний"></input>
        <div>{warn}</div>
        <div>{cool}</div>
        <button onClick={()=>(PostReg())}>Регистрация</button>
        </div>

    )
}
export default Register;