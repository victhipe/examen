
import { useEffect, useState } from 'react'
import './header.css'

function Header({Setpages}){


    const user = JSON.parse(localStorage.getItem('login'));
    

  const token = localStorage.getItem('token')
 // /  useEffect(()=>{
  // /  if(!token){
   // /   return;
  // /  }
  // /  try{
  // /    const payload = token.split(".")[1];
  // /    const decode = JSON.parse(atob(payload));
   // /   Setuser(decode.login);
  // /  }catch(e){
   // /   console.log('Ошибка' +e)
  // /  }///
 // /   
   // /   }, [])
   function destroysession(){
    localStorage.clear();
    window.location.reload();
   }
    console.log(user);
    
    return(
        <div className="header">
      <button>Профиль</button>
       <button onClick={()=>{Setpages('aboutme')}}>О нас</button>
       <button onClick={()=>{Setpages('contact')}}>Контакты</button>
       <button onClick={()=>{Setpages('cart')}}>Корзинка</button>
       <button onClick={()=>{Setpages('main')}}>Товары</button>
       <button onClick={()=>{Setpages('statie')}}>Статьи</button>
       <div>{user}</div>
       {!token ? (<><button onClick={()=>{Setpages('regiser')}}>Регистрация</button>
        <button onClick={()=>{Setpages('login')}}>Логин</button> </>) : (<><button onClick={()=>(destroysession())}> Удалить сессию</button></>)
    
    }
        </div>
    )
}
export default Header;