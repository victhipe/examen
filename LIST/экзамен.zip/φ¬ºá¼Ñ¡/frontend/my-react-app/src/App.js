import { useState } from 'react';
import './App.css';
import Header from './header';
import Aboutme from './aboutme';
import Contact from './contact';
import Main from './main';
import Register from './register';
import Login from './login';
import Cart from './cart';
import Statie from './statie';

function App() {
  const [pages, Setpages] = useState('contact');
    const page = {
        'aboutme': <Aboutme/>, 
        'contact': <Contact/>,
        'main': <Main/>,
        'regiser': <Register/>,
        'login': <Login/>,
        'cart': <Cart/>,
        'statie': <Statie/>
    }
  return (
    <>
    <Header Setpages={Setpages}/>
    {page[pages]}
    </>
  )
}

export default App;
