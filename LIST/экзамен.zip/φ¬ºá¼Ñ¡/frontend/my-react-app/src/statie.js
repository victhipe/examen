function Statie(){

    return(
        <div>

   <div>Статьи</div>
   <div>«Топ‑10 брендов спортивной одежды 2026 года»</div>
   <div>Найк</div>
      <div>Найк</div>
         <div>Найк</div>
            <div>Найк</div>
               <div>Найк</div>
                  <div>Найк</div>
                     <div>Найк</div>
        </div>
    )
}
export default Statie;