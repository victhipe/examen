import { useEffect, useState } from "react";

function Product(){
    const [product, Setproduct] = useState([]);
    useEffect(()=>{
        fetch('http://localhost:9001/api/product')
        .then(res=>res.json())
        .then(data=>{Setproduct(data); console.log(product)})
        .catch(err=>console.log(err))
    },[])
    function cart2item(item){
const cart = JSON.parse(localStorage.getItem('cart') || '[]');
  cart.push(item);
  localStorage.setItem('cart', JSON.stringify(cart));
    }
    return(
        <>
   {product.map((item)=>(<div key={item._id}>
    <div>{item.cost}</div>
     <div>{item.name}</div>
     <div>{item.type}</div>
     <button onClick={()=>(cart2item(item))}>Заказать</button>
   </div>))}
        </>
    )
}
export default Product;