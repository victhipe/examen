import { useEffect, useState } from "react";
import "./product.css"
function Product(){
    const [product, Setproduct] = useState([]);
    const [seach, Setseach] = useState('')
    useEffect(()=>{
        fetch('http://localhost:9001/api/product')
        .then(res=>res.json())
        .then(data=>{Setproduct(data); console.log(product)})
        .catch(err=>console.log(err))
    },[])
    function Cart2item(item){
  const cart = localStorage.getItem(JSON.parse('cart') || '[]');
  cart.push(item);
  localStorage.setItem('cart', JSON.parse(cart));
    }

    return(
        <>
   {product.map((item)=>(<div key={item._id} className="cardboard">
    <div>{item.cost}</div>
     <div>{item.name}</div>
     <div>{item.type}</div>
     <button onClick={()=>(Cart2item)}>Заказать</button>
   </div>))}
        </>
    )
}
export default Product;